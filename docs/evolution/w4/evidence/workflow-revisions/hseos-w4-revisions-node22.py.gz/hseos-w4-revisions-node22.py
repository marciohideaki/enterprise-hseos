import os, pathlib, subprocess
root=pathlib.Path('/workspace/github/marciohideaki/enterprise-hseos/.worktrees/hseos-w4-workflow-revisions')
modules=root/'node_modules'
link=modules/'better-sqlite3'
if link.exists() or link.is_symlink(): raise RuntimeError('Refusing to replace existing ABI binding')
modules.mkdir(exist_ok=True)
link.symlink_to('/build/tmp/hseos-w3-integral-consumer-jhve_lsd/node22/node_modules/better-sqlite3',target_is_directory=True)
env=os.environ.copy()
env['PATH']='/build/tmp/hseos-w1-node/node-v22.23.3-linux-x64/bin:'+env['PATH']
try:
 with (root/'.logs/validation/revisions-kernel-node22.log').open('w') as log:
  result=subprocess.run(['heavy-run','--pin','--mem','3G','--','systemd-run','--user','--scope','--quiet','--collect','--unit=hseos-w4-revisions-node22','-p','Delegate=yes','-p','MemoryMax=3G','-p','MemorySwapMax=0','python3','/tmp/hseos-w4-contained.py','python3','/tmp/hseos-w4-revisions-kernel22.py'],cwd=root,env=env,stdout=log,stderr=subprocess.STDOUT)
 print('Node22 exit:',result.returncode,flush=True)
 raise SystemExit(result.returncode)
finally:
 link.unlink()
 if not any(modules.iterdir()): modules.rmdir()
