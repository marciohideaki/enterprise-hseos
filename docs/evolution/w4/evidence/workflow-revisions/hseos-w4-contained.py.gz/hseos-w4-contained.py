import os,pathlib,sys
base=pathlib.Path('/sys/fs/cgroup') / pathlib.Path('/proc/self/cgroup').read_text().strip()[3:].lstrip('/')
child=base/'controller'
child.mkdir()
(child/'cgroup.procs').write_text(str(os.getpid()))
(base/'cgroup.subtree_control').write_text('+memory +pids')
print('W4 containment:',base,'memory.max=',(base/'memory.max').read_text().strip(),'affinity=',sorted(os.sched_getaffinity(0)),flush=True)
os.execvp(sys.argv[1],sys.argv[1:])
