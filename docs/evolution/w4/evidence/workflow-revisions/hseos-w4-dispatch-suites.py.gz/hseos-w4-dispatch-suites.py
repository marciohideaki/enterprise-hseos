import subprocess
commands=[['npm','run','test:kernel'],['node','--test','--test-concurrency=1','test/test-execution-event-ledger.js','test/test-operational-state-db.js','test/test-agentic-activation-rehearsal.js','test/test-compatibility-audit.js','test/test-native-entrypoint-wiring.js','test/test-execution-projections.js','test/test-governed-execution-runtime.js']]
for command in commands:
 r=subprocess.run(command)
 if r.returncode: raise SystemExit(r.returncode)
