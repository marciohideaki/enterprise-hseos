import subprocess, json, pathlib
root=pathlib.Path.cwd()
critical=['tools/cli/lib/'+name+'.js' for name in ['job-dispatch','job-materialization','job-control','job-worker','engineering-control','engineering-task-runtime','engineering-task-state','engineering-workflow-runtime','engineering-workspace','terminal-control']]+['tools/mcp-project-state/lib/execution-ledger-schema.js','tools/lib/job-contract.js']
scripts=json.loads((root/'package.json').read_text())['scripts']
# Commands are repository-owned and sequential, with a single worker per runner.
command=['node','../../node_modules/c8/bin/c8.js','--all',*[f'--include={name}' for name in critical], '--reporter=text','--reporter=json-summary','--reporter=json','--reports-dir=.logs/validation/revisions-kernel-coverage-node22','--temp-directory=.logs/validation/revisions-kernel-coverage-node22/tmp','--check-coverage','--per-file','--lines=90','--branches=80','python3','/tmp/hseos-w4-dispatch-suites.py']
raise SystemExit(subprocess.run(command).returncode)
